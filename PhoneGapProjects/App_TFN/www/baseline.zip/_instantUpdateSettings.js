function _instantUpdateSettings() {
return {
	"baseLineGUID": "ebf7bda45c5a4c00998fc5db2bc0f6bc",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Please wait while the app is prepared for first-time use."
};
}