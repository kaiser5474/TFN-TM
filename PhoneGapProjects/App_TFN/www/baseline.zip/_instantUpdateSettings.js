function _instantUpdateSettings() {
return {
	"baseLineGUID": "9c92943f67114437a87256f62f72992f",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Please wait while the app is prepared for first-time use."
};
}