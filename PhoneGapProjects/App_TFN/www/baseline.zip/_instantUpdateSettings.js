function _instantUpdateSettings() {
return {
	"baseLineGUID": "b6f01609e1644873a60d61352f704836",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Please wait while the app is prepared for first-time use."
};
}